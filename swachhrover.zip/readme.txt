// SWACHH BOT //  TEAM B

-Verify the bot circuit submitted in the lab with what is given in the report.
-Connect usb cable to arduino with pc.
-Open arduino uno IDE and compile and burn "line_follower_obstacle_detection.ino" file.
-After successfully uploading the code, connect power supply/LiPo battery.

//NOW THE BOT WILL FOLLOW BLACK LINE AND WILL DETECT OBSTACLE AND STOP//

-For the waste segregation part, upload "code_for_obstacle_avoidance.ino" file.
-After successfully uploading the code, connect power supply/LiPo battery.

//NOW THE BOT WILL FOLLOW THE BLACK LINE AND WILL AVOID THE ENCOUNTERED OBSTACLE BY SWITCHING THE BLACK LINE FOR SOME TIME(using delay action) AND AFTER THAT WILL COME BACK TO THE BLACK LINE WITH THE WASTE MOVED TO THE LEFT OR RIGHT BASED ON THE DECISION OF COLOR SENSOR.  